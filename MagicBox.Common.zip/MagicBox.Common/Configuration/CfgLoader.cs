﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicBox.Common.Configuration
{
    public delegate void ConfigLoad(object sender,EventArgs args );

    public class CfgLoader
    {
        public CfgLoader()
        {
        }

    }
}
